import java.awt.Robot;
import java.awt.AWTException;

public class DeplacerSouris
{
    public static void main(String[] args) {
        try {
            // Créer une instance de Robot
            Robot robot = new Robot();
            
            // Déplacer la souris à la position (500, 300) sur l'écran
            robot.mouseMove(500, 300);
            
            // Pause de 2 secondes
            Thread.sleep(2000);
            
            // Déplacer la souris à une nouvelle position
            robot.mouseMove(100, 100);
        } catch (AWTException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

