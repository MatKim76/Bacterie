pkill -KILL -u $USER
