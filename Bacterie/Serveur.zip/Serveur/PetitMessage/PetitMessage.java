package PetitMessage;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.*;

public class PetitMessage extends JFrame
{
	
	public PetitMessage( String message )
	{
		this.setSize(200,200);
		this.setPos(400,200);
		
		this.setVisible(true);
	}

}
